<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderPhoto;

class OrderApiController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }

    public function index()
    {
        $orders = Order::with('orderPhotos')->get();
        return response()->json(['orders' => $orders], 200);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'address' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'zip_code' => 'required|string|max:20',
            'phone' => 'required|string|max:20',
            // 'images.*' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $totalPrice = 0;

        if($request->has('images')){
            foreach ($request->input('images') as $imageData) {
                $quantity = $imageData['quantity'];
                $sizeId = $imageData['size'];

                $canvasPrice = Canvas::find($sizeId)->price;

                $imagePrice = $canvasPrice * $quantity;
                $totalPrice += $imagePrice;
            }
        }

        $order = new Order([
            'first_name' => $request->input('first_name'),
            'last_name' => $request->input('last_name'),
            'email' => $request->input('email'),
            'address' => $request->input('address'),
            'country' => $request->input('country'),
            'city' => $request->input('city'),
            'zip_code' => $request->input('zip_code'),
            'phone' => $request->input('phone'),
            'total_price' => $totalPrice,
        ]);

        $order->save();

        $orderPhotos = [];
        if($request->has('images')){
            foreach ($request->input('images') as $imageData) {
                $imageFile = $imageData['file'];
                $quantity = $imageData['quantity'];
                $sizeId = $imageData['size'];
                $paperType = $imageData['paper_type'];

                $fileName = uniqid() . '.' . $imageFile->getClientOriginalExtension();

                $orderFolder = 'orders/' . $order->id;
                if (!Storage::exists($orderFolder)) {
                    Storage::makeDirectory($orderFolder);
                }

                $imagePath = $imageFile->storeAs($orderFolder, $fileName);

                $orderPhoto = new OrderPhoto([
                    'order_id' => $order->id,
                    'image' => $imagePath,
                    'size' => $sizeId,
                    'quantity' => $quantity,
                    'paper_type' => $paperType,
                ]);

                $orderPhoto->save();

                $orderPhotos[] = $orderPhoto;
            }
        }

        // return response()->json([
        //     'order' => $order,
        //     'order_photos' => $orderPhotos,
        // ], 201); // Răspuns "Created" (HTTP 201)

        return response()->json(['message' => 'Comanda a fost creată cu succes'], 201);
    }

}
